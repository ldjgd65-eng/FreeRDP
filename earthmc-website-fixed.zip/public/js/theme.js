document.addEventListener('DOMContentLoaded', () => {
    const dot = document.getElementById('cursor-dot');
    const ring = document.getElementById('cursor-ring');
    const crosshair = document.getElementById('cursor-crosshair');
    
    const spaceBg = document.querySelector('.space-bg');
    const nebula = document.querySelector('.nebula-layer');
    const canvas = document.getElementById('spaceCanvas');

    window.addEventListener('mousemove', (e) => {
        const { clientX: x, clientY: y } = e;

        // Perfectly centered cursor using hardware acceleration
        const cursorPath = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%)`;
        if (dot) dot.style.transform = cursorPath;
        if (ring) ring.style.transform = cursorPath;
        if (crosshair) crosshair.style.transform = cursorPath;

        // Parallax Background Effect
        if (spaceBg) {
            const moveX = (x / window.innerWidth - 0.5) * 20;
            const moveY = (y / window.innerHeight - 0.5) * 20;
            spaceBg.style.transform = `translate3d(${moveX}px, ${moveY}px, 0) scale(1.15)`;
        }

        if (nebula) {
            const moveX = (x / window.innerWidth - 0.5) * 40;
            const moveY = (y / window.innerHeight - 0.5) * 40;
            nebula.style.transform = `translate3d(${moveX}px, ${moveY}px, 0) scale(1.25)`;
        }
    });

    // --- STARFIELD ANIMATION ---
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let stars = [];
        const starCount = 100;

        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            initStars();
        };

        const initStars = () => {
            stars = [];
            for (let i = 0; i < starCount; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    size: Math.random() * 1.5,
                    opacity: Math.random(),
                    speed: Math.random() * 0.5 + 0.1
                });
            }
        };

        const draw = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = "#fff";

            stars.forEach(star => {
                ctx.globalAlpha = star.opacity;
                ctx.beginPath();
                ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
                ctx.fill();

                // Subtle cosmic drift
                star.y += star.speed;
                if (star.y > canvas.height) star.y = 0;
            });

            requestAnimationFrame(draw);
        };

        window.addEventListener('resize', resize);
        resize();
        draw();
    }

    // Handle interaction states
    const interactables = document.querySelectorAll('a, button, input, textarea, .mode-card, .vote-btn');
    interactables.forEach(el => {
        el.addEventListener('mouseenter', () => {
            document.body.classList.add('cursor-hover');
            if (ring) ring.style.width = '60px';
            if (ring) ring.style.height = '60px';
            if (ring) ring.style.borderColor = 'var(--pulsar-cyan)';
        });
        el.addEventListener('mouseleave', () => {
            document.body.classList.remove('cursor-hover');
            if (ring) ring.style.width = '40px';
            if (ring) ring.style.height = '40px';
            if (ring) ring.style.borderColor = 'rgba(0, 243, 255, 0.3)';
        });
    });
});