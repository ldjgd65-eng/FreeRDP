const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'earthmc-secret-key-2025',
  resave: false,
  saveUninitialized: true
}));

const defaultConfig = {
  siteName: 'EarthMC',
  serverIp: 'play.earthmc.net',
  storeUrl: 'https://store.earthmc.qzz.io',
  discordUrl: '#',
  mapUrl: 'https://map.earthmc.qzz.io',
  donateUrl: '/donate',
  heroTitle: 'EarthMC',
  heroDesc: 'The ultimate Geopolitical Earth network — conquer nations, build civilizations, and make your mark on the world. Your legend begins now.',
  logoUrl: '',
  logoText: 'EMC',
  faviconUrl: '',
  // Social media
  youtubeUrl: '', youtubeHandle: '',
  twitterUrl: '', twitterHandle: '',
  tiktokUrl: '', tiktokHandle: '',
  instagramUrl: '', instagramHandle: '',
  redditUrl: '', redditHandle: '',
};

let config = { ...defaultConfig };
let announcements = [
  { id: '1', title: 'Welcome to EarthMC!', body: 'The network is live. Join the geopolitics realm now!', created_at: '2025-01-20' },
  { id: '2', title: 'New Geopolitical Realm', body: 'Survival on a 1:1000 scale replica of the world — conquer and build!', created_at: '2025-01-18' }
];
let applications = [];
let ADMIN_PASSWORD = 'earthmcadmin';

// Persistence helpers
const configPath = path.join(__dirname, 'config.json');
const annPath = path.join(__dirname, 'announcements.json');
const appsPath = path.join(__dirname, 'applications.json');

function loadConfig() {
  try { const d = JSON.parse(fs.readFileSync(configPath)); config = { ...defaultConfig, ...d }; } catch(e) { config = { ...defaultConfig }; }
}
function saveConfig() { fs.writeFileSync(configPath, JSON.stringify(config, null, 2)); }
function loadAnnouncements() {
  try { announcements = JSON.parse(fs.readFileSync(annPath)); } catch(e) {}
}
function saveAnnouncements() { fs.writeFileSync(annPath, JSON.stringify(announcements, null, 2)); }
function loadApplications() {
  try { applications = JSON.parse(fs.readFileSync(appsPath)); } catch(e) {}
}
function saveApplications() { fs.writeFileSync(appsPath, JSON.stringify(applications, null, 2)); }

// Load stored admin password override
function loadPassword() {
  try {
    const p = JSON.parse(fs.readFileSync(path.join(__dirname, 'admin-pass.json')));
    if (p.password) ADMIN_PASSWORD = p.password;
  } catch(e) {}
}

// Middleware: inject globals into every view
app.use((req, res, next) => {
  res.locals.cfg = config;
  res.locals.title = config.siteName;
  res.locals.announcements = announcements;
  next();
});

// ─── PUBLIC ROUTES ───
app.get('/', (req, res) => res.render('index'));
app.get('/vote', (req, res) => res.render('vote'));
app.get('/wiki', (req, res) => res.render('wiki'));
app.get('/donate', (req, res) => res.render('donate'));

app.get('/store', (req, res) => res.redirect(config.storeUrl || 'https://store.earthmc.qzz.io'));
app.get('/map', (req, res) => res.redirect(config.mapUrl || 'https://map.earthmc.qzz.io'));

app.get('/apply', (req, res) => {
  const n1 = Math.floor(Math.random() * 10) + 1;
  const n2 = Math.floor(Math.random() * 10) + 1;
  req.session.captchaAns = n1 + n2;
  res.render('apply', { captcha: { n1, n2 }, error: req.query.error });
});

app.post('/apply', (req, res) => {
  const { legalName, mcUsername, age, email, discord, why, captchaAns } = req.body;
  if (parseInt(captchaAns) !== req.session.captchaAns) {
    return res.redirect('/apply?error=Incorrect+captcha+answer');
  }
  applications.push({ id: uuidv4(), legalName, mcUsername, age, email, discord, why, status: 'pending', timestamp: new Date().toISOString() });
  saveApplications();
  res.redirect('/apply?success=true');
});

// ─── ADMIN AUTH ───
app.get('/admin/login', (req, res) => res.render('admin-login', { error: null }));
app.post('/admin/login', (req, res) => {
  if (req.body.password === ADMIN_PASSWORD) {
    req.session.admin = true;
    res.redirect('/admin/dashboard');
  } else {
    res.render('admin-login', { error: 'Invalid password' });
  }
});
app.get('/admin/logout', (req, res) => { req.session.destroy(); res.redirect('/'); });

const requireAdmin = (req, res, next) => req.session.admin ? next() : res.redirect('/admin/login');

app.get('/admin/dashboard', requireAdmin, (req, res) => {
  res.render('admin-dashboard', {
    cfg: config,
    apps: applications,
    pendingCount: applications.filter(a => a.status === 'pending').length
  });
});

// ─── ADMIN API: CONFIG ───
app.get('/api/admin/config', requireAdmin, (req, res) => res.json({ success: true, data: config }));
app.post('/api/admin/config', requireAdmin, (req, res) => {
  config = { ...config, ...req.body };
  saveConfig();
  res.json({ success: true });
});

// ─── ADMIN API: ANNOUNCEMENTS ───
app.get('/api/admin/announcements', requireAdmin, (req, res) => res.json({ success: true, data: announcements }));
app.post('/api/admin/announcements', requireAdmin, (req, res) => {
  if (req.body.announcements) {
    announcements = req.body.announcements;
    saveAnnouncements();
  }
  res.json({ success: true });
});

// ─── ADMIN API: APPLICATIONS ───
app.get('/api/admin/applicants', requireAdmin, (req, res) => res.json({ success: true, data: applications }));
app.post('/api/admin/applicants/:id/:status', requireAdmin, (req, res) => {
  const a = applications.find(x => x.id === req.params.id);
  if (a) { a.status = req.params.status; saveApplications(); }
  res.json({ success: true });
});
app.delete('/api/admin/applicants/:id', requireAdmin, (req, res) => {
  applications = applications.filter(x => x.id !== req.params.id);
  saveApplications();
  res.json({ success: true });
});

// ─── ADMIN API: PASSWORD ───
app.post('/api/admin/password', requireAdmin, (req, res) => {
  const { password } = req.body;
  if (!password || password.length < 6) return res.json({ success: false, error: 'Too short' });
  ADMIN_PASSWORD = password;
  fs.writeFileSync(path.join(__dirname, 'admin-pass.json'), JSON.stringify({ password }));
  res.json({ success: true });
});

// ─── PUBLIC API ───
app.get('/api/status', (req, res) => res.json({ players: Math.floor(Math.random() * 50) + 20 }));

// ─── STARTUP ───
loadConfig();
loadAnnouncements();
loadApplications();
loadPassword();

app.listen(PORT, () => console.log(`${config.siteName} running on http://localhost:${PORT}`));
